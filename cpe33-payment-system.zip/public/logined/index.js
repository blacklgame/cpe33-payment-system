/* ------------------------------------------------------------
   1) Sync this page to whichever Nu ID logged in
------------------------------------------------------------ */
import { doc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { db } from "../firebase.js";

const raw = sessionStorage.getItem("cpe33_user");
let user = null;

if (!raw) {
  // No one is logged in -> send back to the login page
  window.location.href = "../index.html";
} else {
  user = JSON.parse(raw);

  document.getElementById("userName").textContent = user.name;
  document.getElementById("userEmail").textContent = user.email;
}

document.getElementById("logoutLink").addEventListener("click", (e) => {
  e.preventDefault();
  sessionStorage.removeItem("cpe33_user");
  window.location.href = "../index.html";
});

/* ------------------------------------------------------------
   2) Choose File -> preview -> Send (upload payment slip)

   Slip images upload straight from the browser to Cloudinary
   (an "unsigned upload" -- no server involved, no file-size cap
   from Vercel's serverless function body limit anymore).

   Fill in your own values from the Cloudinary dashboard:
   - CLOUDINARY_CLOUD_NAME: Console home page, top of the page
   - CLOUDINARY_UPLOAD_PRESET: Settings -> Upload -> Upload presets
     -> Add upload preset -> set Signing Mode to "Unsigned"
------------------------------------------------------------ */
const CLOUDINARY_CLOUD_NAME = "egcc6hml";
const CLOUDINARY_UPLOAD_PRESET = "cpe33_slips";

const fileInput = document.getElementById("fileInput");
const fileNameLabel = document.getElementById("fileName");
const previewWrap = document.getElementById("previewWrap");
const previewImg = document.getElementById("previewImg");
const sendBtn = document.getElementById("sendBtn");
const statusText = document.getElementById("statusText");

let selectedFile = null;

fileInput.addEventListener("change", () => {
  statusText.textContent = "";
  statusText.className = "status-text";

  const file = fileInput.files[0];

  if (!file) {
    selectedFile = null;
    fileNameLabel.textContent = "ยังไม่ได้เลือกไฟล์";
    previewWrap.classList.remove("show");
    sendBtn.disabled = true;
    return;
  }

  if (!file.type.startsWith("image/")) {
    statusText.textContent = "กรุณาเลือกไฟล์รูปภาพเท่านั้น";
    statusText.className = "status-text error";
    fileInput.value = "";
    selectedFile = null;
    previewWrap.classList.remove("show");
    sendBtn.disabled = true;
    return;
  }

  const MAX_BYTES = 10 * 1024 * 1024;
  if (file.size > MAX_BYTES) {
    statusText.textContent = "ไฟล์ใหญ่เกินไป (สูงสุด 10MB) กรุณาเลือกไฟล์อื่น";
    statusText.className = "status-text error";
    fileInput.value = "";
    selectedFile = null;
    previewWrap.classList.remove("show");
    sendBtn.disabled = true;
    return;
  }

  selectedFile = file;
  fileNameLabel.textContent = file.name;
  sendBtn.disabled = false;

  // Show a preview of the picked image
  const reader = new FileReader();
  reader.onload = (e) => {
    previewImg.src = e.target.result;
    previewWrap.classList.add("show");
  };
  reader.readAsDataURL(file);
});

sendBtn.addEventListener("click", async () => {
  if (!selectedFile || !user) return;

  sendBtn.disabled = true;
  sendBtn.textContent = "กำลังส่ง...";
  statusText.textContent = "";
  statusText.className = "status-text";

  try {
    // 1) Upload the slip image straight to Cloudinary, under a
    //    public_id named after this user's Nu ID -- so each
    //    student's slips only ever live under slips/{their own
    //    id}/... The upload preset (set in the Cloudinary
    //    dashboard) applies q_auto/f_auto compression automatically,
    //    so a 3-5MB phone photo typically lands well under 1MB.
    const safeName = selectedFile.name
      .replace(/\.[^/.]+$/, "")
      .replace(/[^a-zA-Z0-9_-]/g, "_");
    const publicId = `slips/${user.id}/${Date.now()}_${safeName}`;

    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("upload_preset", CLOUDINARY_UPLOAD_PRESET);
    formData.append("public_id", publicId);

    const uploadRes = await fetch(
      `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`,
      { method: "POST", body: formData }
    );

    if (!uploadRes.ok) {
      const errBody = await uploadRes.json().catch(() => ({}));
      throw new Error(errBody.error?.message || "Upload failed");
    }

    const result = await uploadRes.json();
    const slipUrl = result.secure_url;

    // 2) Record the payment in Firestore, keyed by Nu ID, so the
    //    Stats page can look it up by that same ID. slipPublicId is
    //    saved too so the admin dashboard can delete the exact
    //    Cloudinary asset later without guessing it from the URL.
    await setDoc(doc(db, "payments", user.id), {
      paid: true,
      fileName: selectedFile.name,
      slipUrl,
      slipPublicId: result.public_id,
      uploadedAt: serverTimestamp()
    });

    statusText.textContent = `อัปโหลด "${selectedFile.name}" สำเร็จ`;
    statusText.className = "status-text success";
  } catch (err) {
    console.error("Upload failed:", err);
    statusText.textContent = "อัปโหลดไม่สำเร็จ กรุณาลองใหม่อีกครั้ง";
    statusText.className = "status-text error";
  } finally {
    sendBtn.textContent = "ส่ง (Send)";
    sendBtn.disabled = false;
  }
});
