/* ------------------------------------------------------------
   Firebase project init. Shared by every page that talks to
   Firestore/Storage -- they each `import` from this file.
------------------------------------------------------------ */
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { getAuth, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

// Note: Firebase Storage is no longer used -- payment slip images now
// upload straight to Cloudinary from the browser instead (Firebase
// Storage requires the paid Blaze plan even for small usage). See
// public/logined/index.js.

const firebaseConfig = {
  apiKey: "AIzaSyCUrDGPZq3gpD7ccee_CCaT89KUeSjmUnQ",
  authDomain: "cpe33-79979.firebaseapp.com",
  projectId: "cpe33-79979",
  storageBucket: "cpe33-79979.firebasestorage.app",
  messagingSenderId: "130126006962",
  appId: "1:130126006962:web:bf07c5b9db7634b16c57ab"
};

const app = initializeApp(firebaseConfig);

const db = getFirestore(app);
const auth = getAuth(app);

/* ------------------------------------------------------------
   This app has no real password login (Nu ID only), so there's
   no "real" account to sign in to. Anonymous auth just gives the
   browser a signed-in session so our security rules can require
   "must be signed in" before writing -- this blocks randoms from
   writing to the database directly without going through the app
   at all. It does NOT verify that someone typing a Nu ID actually
   owns it (the app doesn't have that concept yet).

   IMPORTANT: this file is shared by the admin pages too, which sign
   in with Google instead. signInAnonymously() only reuses the
   current session if it's already anonymous -- if a Google session
   is active, calling it blindly REPLACES that session with a new
   anonymous one, silently signing the admin out. So we wait for
   Firebase to resolve whatever session already exists (restored
   from storage, e.g. an existing Google login) and only sign in
   anonymously if there's truly nobody signed in yet.
------------------------------------------------------------ */
const unsubscribeInitialAuth = onAuthStateChanged(auth, (user) => {
  unsubscribeInitialAuth();
  if (!user) {
    signInAnonymously(auth).catch((err) => {
      console.error("Anonymous sign-in failed:", err);
    });
  }
});

export { app, db, auth };
