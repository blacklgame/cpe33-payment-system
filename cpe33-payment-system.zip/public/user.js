const USERS = {
  "69360013": {
    id: "69360013",
    name: "นางสาวกชพรรณ พรหมสิทธิ์",
    email: "kotchaphanph69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360020": {
    id: "69360020",
    name: "นางสาวกนกนาฏ คำอ้าย",
    email: "kanoknatk69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360037": {
    id: "69360037",
    name: "นายกฤษณะ บุตรใจ",
    email: "kitsanab69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360044": {
    id: "69360044",
    name: "นายกานต์ ดีรักษา",
    email: "kand69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360051": {
    id: "69360051",
    name: "นายกิตติศักดิ์ ดอนชาไพร",
    email: "kittisakd69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360068": {
    id: "69360068",
    name: "นายกิติพัฒน์ พุทธโกสัย",
    email: "kitiphatp69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360075": {
    id: "69360075",
    name: "นางสาวเกวลี ปันทะนะ",
    email: "keowalip69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360082": {
    id: "69360082",
    name: "นายเกื้อกูล ศรีสวาท",
    email: "kueakuns69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360099": {
    id: "69360099",
    name: "นายจักราวุธ อุทธโยธา",
    email: "chakkrawuta69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360105": {
    id: "69360105",
    name: "นายจารุภัทร พิมจันทร์",
    email: "jarupatp69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360112": {
    id: "69360112",
    name: "นางสาวจิตรลดา ปูรณัน",
    email: "jitladap69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360129": {
    id: "69360129",
    name: "นายจิรวัฒน์ คำพุธ",
    email: "jirawatk69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360136": {
    id: "69360136",
    name: "นางสาวชฎากรณ์ ธรรมชาติ",
    email: "chadakhont69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360143": {
    id: "69360143",
    name: "นางสาวชฎิลนภัส เสนอินทร์",
    email: "chadinnapass69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360150": {
    id: "69360150",
    name: "นายชนกันต์ กาวิชัย",
    email: "chanakank69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360167": {
    id: "69360167",
    name: "นายชนสิทธิ์ จิรธนไพศาลสกุล",
    email: "chanasitj69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360174": {
    id: "69360174",
    name: "นางสาวชยิสรา พุ่มจีน",
    email: "chayisarap69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360181": {
    id: "69360181",
    name: "นายชิตชิโนรส ทิมทอง",
    email: "chitchinorost69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360198": {
    id: "69360198",
    name: "นายชิษณุพงศ์ จิ๋วน๊อต",
    email: "chitsanuphongj69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360204": {
    id: "69360204",
    name: "นายณกัน ผณีกานณ์",
    email: "nakanp69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360211": {
    id: "69360211",
    name: "นายณรงค์ คงสมปราชญ์",
    email: "narongk69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360228": {
    id: "69360228",
    name: "นายณัฎฐกรณ์ จักรเสน",
    email: "natakornj69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360235": {
    id: "69360235",
    name: "นายณัฏฐกิตติ์ ทิมสูงเนิน",
    email: "nattakitt69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360242": {
    id: "69360242",
    name: "นางสาวณัฏฐณิชา สระทองจันทร์",
    email: "natthanichasa69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360259": {
    id: "69360259",
    name: "นายณัฏฐวี ลาภยิ่ง",
    email: "nattaveel69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360266": {
    id: "69360266",
    name: "นายณัฐพงศ์ ศิริเมือง",
    email: "natthaphongsi69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360273": {
    id: "69360273",
    name: "นายณัฐพล อินทร์อิ่ม",
    email: "natthaphona69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360280": {
    id: "69360280",
    name: "นายณัฐพล จันทร์มณี",
    email: "natthaphoncha69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360303": {
    id: "69360303",
    name: "นายณัฐพัชร์ เบ้าตุ้ม",
    email: "natthaphatb69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360310": {
    id: "69360310",
    name: "นายณัฐวัฒน์ เสนภูงา",
    email: "nattawats69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360327": {
    id: "69360327",
    name: "นายณัทรัฏฐ์ ใจแล",
    email: "nattharatj69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360334": {
    id: "69360334",
    name: "นายตปธน ประดิษฐ์สถาพร",
    email: "trapatonp69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360341": {
    id: "69360341",
    name: "นางสาวตักวาย์ หะยีหะมะ",
    email: "taqwah69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360358": {
    id: "69360358",
    name: "นายถิรวัฒน์ ศรีคำ",
    email: "thirawats69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360365": {
    id: "69360365",
    name: "นายธนดล สามิน",
    email: "thanadols69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360372": {
    id: "69360372",
    name: "นางสาวธนพร ดอนชาไพร",
    email: "thanapornd69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360389": {
    id: "69360389",
    name: "นายธนัชชา โกวาฤทธิ์",
    email: "thanatchak69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360396": {
    id: "69360396",
    name: "นายธนัชทัพพ์ ทองใบ",
    email: "thanatchatupt69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360402": {
    id: "69360402",
    name: "นางสาวธัญญาภรณ์ พาณิชย์โรจกุล",
    email: "thanyapornph69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360419": {
    id: "69360419",
    name: "นายธารธร วงศ์คำ",
    email: "tarnthonw69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360426": {
    id: "69360426",
    name: "นายธีรวุธ บุตรลพ",
    email: "teerawutb69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360433": {
    id: "69360433",
    name: "นายนพฤทธิ์ จีนเพชร",
    email: "nopparitj69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360440": {
    id: "69360440",
    name: "นางสาวนรมน ไชยวงศ์",
    email: "naramonc69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360457": {
    id: "69360457",
    name: "นายนันทพงศ์ น้อยเดช",
    email: "nanthaphongn69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360464": {
    id: "69360464",
    name: "นายนันทิกร โพธิ์ปี",
    email: "nantikornp69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360471": {
    id: "69360471",
    name: "นายนิติภูมิ พรามพิลา",
    email: "nitiphump69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360488": {
    id: "69360488",
    name: "นางสาวนีรชา บุตรผักแว่น",
    email: "neerachab69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360495": {
    id: "69360495",
    name: "นายปฏิภาณ บุญเยี่ยม",
    email: "patiphanb69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360501": {
    id: "69360501",
    name: "นายปฐพี สินไพบูลย์",
    email: "patapees69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360518": {
    id: "69360518",
    name: "นางสาวปภาวรินท์ สุริโยปการ",
    email: "papavarins69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360525": {
    id: "69360525",
    name: "นางสาวปริชญา อินทร์แก้ว",
    email: "paritchayaa69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360532": {
    id: "69360532",
    name: "นายปัณณธร บุญพึ่ง",
    email: "punnathornb69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360549": {
    id: "69360549",
    name: "นายปิยะวัฒน์ ไพรธี",
    email: "piyawatp69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360556": {
    id: "69360556",
    name: "นายปิลันธสุทธิ์ จันทะวงศ์",
    email: "piluntasuttj69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360563": {
    id: "69360563",
    name: "นายพงศภัทร ผูกคล้าย",
    email: "pongsaphatp69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360570": {
    id: "69360570",
    name: "นางสาวพนัชกร ยอดคง",
    email: "phanatchagony69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360587": {
    id: "69360587",
    name: "นายพรพิพัฒน์ ฉิมเสือ",
    email: "pornpipatc69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360594": {
    id: "69360594",
    name: "นายพัทธดนย์ หอพิชญพงศ์",
    email: "phattadonh69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360600": {
    id: "69360600",
    name: "นายพิชาภพ นุกูลภักดี",
    email: "phichaphopn69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360617": {
    id: "69360617",
    name: "นางสาวพีรภัทร นิลเกษม",
    email: "peerapatni69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360624": {
    id: "69360624",
    name: "นายภควัต มณีโชติ",
    email: "pakavatm69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360631": {
    id: "69360631",
    name: "นางสาวภัทรดา พยาวัง",
    email: "pataradap69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360648": {
    id: "69360648",
    name: "นายภูพิงค์ มงคล",
    email: "phuphingm69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360655": {
    id: "69360655",
    name: "นายไมตรี เพียงแก้ว",
    email: "maitreep69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360662": {
    id: "69360662",
    name: "นายรพีพงศ์ โตชาวนา",
    email: "rapeephongt69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360679": {
    id: "69360679",
    name: "นายรพีภัทร พรมลา",
    email: "rapeepatp69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360686": {
    id: "69360686",
    name: "นายรัชภูมิ คชพงศ์",
    email: "ratchaphumk69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360693": {
    id: "69360693",
    name: "นางสาววชิรญาณ์ บุญมณี",
    email: "wachirayab69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360709": {
    id: "69360709",
    name: "นายวรกันต์ ปังคานนท์",
    email: "warragunp69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360716": {
    id: "69360716",
    name: "นายวรนน คำไทย",
    email: "woranonk69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360723": {
    id: "69360723",
    name: "นายวรภพ ทับทิมทอง",
    email: "vorraphopt69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360730": {
    id: "69360730",
    name: "นางสาววรรณวิสา ปานจักร",
    email: "wanwisap69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360747": {
    id: "69360747",
    name: "นายวีรภัทร ฉิมอยู่",
    email: "weeraphatc69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360754": {
    id: "69360754",
    name: "นายศรัณญ์ภัทร พงษ์สิงห์",
    email: "saranphatph69@nu.ac.th",
    stat: "พ้นสภาพนิสิต"
  },
  "69360761": {
    id: "69360761",
    name: "นางสาวศรัณย์ภัทร โคตรพันธ์",
    email: "saranphatk69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360778": {
    id: "69360778",
    name: "นายศิลนิธิ คำภาผง",
    email: "sinnithik69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360785": {
    id: "69360785",
    name: "นายสถิตคุณ อุทัยมงคล",
    email: "sathitkunu69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360792": {
    id: "69360792",
    name: "นายสรเดช เนียมชาวนา",
    email: "soradechn69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360808": {
    id: "69360808",
    name: "นายสรวิชญ์ สิทธิอักษร",
    email: "sorawits69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360815": {
    id: "69360815",
    name: "นายสัณหณัฐ ภัทรบุญยพงศ์",
    email: "sunhanatp69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360822": {
    id: "69360822",
    name: "นางสาวสุนทรา ปุ๊ดตัน",
    email: "sunthrap69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360839": {
    id: "69360839",
    name: "นายอติรุจ ธารีวาสน์",
    email: "atirutt69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360846": {
    id: "69360846",
    name: "นายอนันดา พลอาสา",
    email: "anandaph69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360853": {
    id: "69360853",
    name: "นายอภิรักษ์ เอี่ยมโพธิ์",
    email: "aphiraka69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360860": {
    id: "69360860",
    name: "นายอมฤต ชัยสุวรรณ์",
    email: "amaritc69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360877": {
    id: "69360877",
    name: "นายอัครเดช นาคสำราญ",
    email: "oakkhadetn69@nu.ac.th",
    stat: "ปกติ"
  },
  "69360884": {
    id: "69360884",
    name: "นางสาวอิรวดี สินวิริยะนนท์",
    email: "airawadis69@nu.ac.th",
    stat: "ปกติ"
  },
  "69367333": {
    id: "69367333",
    name: "นายเอกธนตนันท์ แตงเกิด",
    email: "aekthanatanunt69@nu.ac.th",
    stat: "ปกติ"
  },
  "69367364": {
    id: "69367364",
    name: "นายยุทธพิชัย สีดาแจ่ม",
    email: "yutthaphichais69@nu.ac.th",
    stat: "ปกติ"
  },
  "69367388": {
    id: "69367388",
    name: "นายภูรี พงษ์มาลา",
    email: "",
    stat: "พ้นสภาพนิสิต"
  },
  "69367470": {
    id: "69367470",
    name: "นายศิวัช ลิ่มชวลิต",
    email: "siwatl69@nu.ac.th",
    stat: "ปกติ"
  }
};